namespace Game339.Shared.Models
{
    public class GameState
    {
        public Character GoodGuy { get; } = new();
        public Character BadGuy { get; } = new();
        public Character Player { get; } = new();

        public ObservableValue<bool> IsInCombat = new();
    }
}