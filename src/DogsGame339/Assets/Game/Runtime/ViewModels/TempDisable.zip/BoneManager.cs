using System;
using Game.Runtime;
using Game339.Shared;
using TMPro;
using UnityEngine;

namespace Game.ViewModels
{
    [Serializable]
    public class ObservableInt : ObservableValue<int>, ISerializationCallbackReceiver
    {
        [SerializeField] private int initialValue;

        public void OnAfterDeserialize()  => Value = initialValue;
        public void OnBeforeSerialize()   => initialValue = Value;
    }

    public class GoodGuyHpView : ObserverMonoBehaviour
    {
        private static Game339.Shared.Models.Game Game => ServiceResolver.Resolve<Game339.Shared.Models.Game>();

        public TextMeshProUGUI thisIsMyLabel;

        public bool useAlternativeMessage;

        protected override void Subscribe()
        {
            Game.GoodGuy.Health.ChangeEvent += OnGoodGuyHealthChange;
        }

        protected override void Unsubscribe()
        {
            Game.GoodGuy.Health.ChangeEvent -= OnGoodGuyHealthChange;
        }

        private void OnGoodGuyHealthChange(int health)
        {
            thisIsMyLabel.text = useAlternativeMessage
                ? "WAT?? -" + health
                : "Health: " + health;
        }
    }
}
